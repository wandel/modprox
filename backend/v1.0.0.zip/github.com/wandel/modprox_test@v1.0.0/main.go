package main

func main(){
	log.Println("version 1.0!")
}